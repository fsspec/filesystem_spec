Development
===========

Create a development environment::

    $ pip install -r requirements.txt -r test_requirements.txt

Run tests::

    $ pytest
