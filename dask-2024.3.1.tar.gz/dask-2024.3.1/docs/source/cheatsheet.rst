:orphan:

Dask Cheat Sheet
================

The 300KB pdf :download:`Dask cheat sheet <daskcheatsheet.pdf>`
is a single page summary about using Dask.
It is commonly distributed at conferences and trade shows.
