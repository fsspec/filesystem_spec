from __future__ import annotations

from dask.array.overlap import sliding_window_view  # noqa: F401
